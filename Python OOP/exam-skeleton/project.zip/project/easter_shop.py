class EasterShop:
    def __init__(self):
        pass

    def add_chocolate_ingredient(self):
        pass

    def add_egg_ingredient(self):
        pass

    def add_paint_ingredient(self):
        pass

    def make_chocolate(self):
        pass

    def paint_egg(self):
        pass

    def __repr__(self):
        pass
