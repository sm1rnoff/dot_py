from project.factory.factory import Factory


class PaintFactory(Factory):
    def __init__(self):
        pass

    def add_ingredient(self):
        pass

    def remove_ingredient(self):
        pass

    @property
    def products(self):
        pass
